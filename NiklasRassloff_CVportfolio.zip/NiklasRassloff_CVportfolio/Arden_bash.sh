#!/bin/bash

FILE="cv.html"

echo "HTML analysis for $FILE"

echo "Number of div taggs:"
grep -oi "<div" "$FILE" | wc -l

echo "Number of img tags:"
grep -oi "<img" "$FILE" | wc -l

echo "Number of linkss:"
grep -oi "<a " "$FILE" | wc -l

echo "number of heading tags:"
grep -Eoi "<h[1-6]" "$FILE" | wc -l
