const currentDate = document.getElementById("currentDate");
const toggleCvBtn = document.getElementById("toggleCvBtn");
const cvSummary = document.getElementById("cvSummarry");
const socialmediabtn = document.getElementById("socialBtn");

if (currentDate) {
  currentDate.textContent = new Date().toLocaleString();
}

if (toggleCvBtn && cvSummary) {

  toggleCvBtn.addEventListener("click", function () {

    if (cvSummary.style.display === "none") {
      cvSummary.style.display = "block";
    } else {
      cvSummary.style.display = "none";
    }

  });

}

if (socialmediabtn) {

  socialmediabtn.addEventListener("click", function () {

    window.open("https://github.com/eaboiniklas-dot", "_blank");

  });

}